-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2026 at 11:37 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_smilemarket`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_category`
--

CREATE TABLE `tb_category` (
  `cat_id` varchar(20) NOT NULL,
  `cat_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tb_category`
--

INSERT INTO `tb_category` (`cat_id`, `cat_name`) VALUES
('CAT001', 'ของหวาน-เบเกอรี่'),
('CAT002', 'ผัก-ผลไม้'),
('CAT003', 'หมวดสุขภาพและความงาม');

-- --------------------------------------------------------

--
-- Table structure for table `tb_member`
--

CREATE TABLE `tb_member` (
  `member_id` varchar(20) NOT NULL,
  `member_email` varchar(50) NOT NULL,
  `member_password` varchar(255) DEFAULT NULL,
  `member_tel` varchar(10) DEFAULT NULL,
  `member_name` varchar(50) NOT NULL,
  `member_lastname` varchar(50) NOT NULL,
  `member_address` varchar(200) DEFAULT NULL,
  `member_sex` int(2) DEFAULT NULL COMMENT '1=ชาย , 2=หญิง',
  `member_birthday` date DEFAULT NULL,
  `member_status` int(1) DEFAULT NULL COMMENT '1=โสด, 2=คู่สมรส, 3=แยกกันอยู่'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tb_member`
--

INSERT INTO `tb_member` (`member_id`, `member_email`, `member_password`, `member_tel`, `member_name`, `member_lastname`, `member_address`, `member_sex`, `member_birthday`, `member_status`) VALUES
('MB00001', 'nattapon@email.com', '$2y$10$.ytmBZW.Ae0Av33ghiFO8uOCt03/rmjCAADLIM2/JdN/Uz5EcIytu', '0123456789', 'Nattapon', 'Trakulbangkla', 'เลขที่ 1 ถนนพระราม 2 ซอย 1 เขตจอมทอง เขตจอมทอง กรุงเทพฯ', 1, '1998-02-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_order`
--

CREATE TABLE `tb_order` (
  `order_id` varchar(20) NOT NULL,
  `member_id` varchar(20) DEFAULT NULL,
  `member_name` varchar(100) DEFAULT NULL,
  `member_tel` varchar(10) DEFAULT NULL,
  `member_address` varchar(500) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `order_slip_image` varchar(100) DEFAULT NULL,
  `order_status` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_orderdetail`
--

CREATE TABLE `tb_orderdetail` (
  `order_id` varchar(20) NOT NULL,
  `member_id` varchar(20) NOT NULL,
  `pro_id` varchar(20) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_product`
--

CREATE TABLE `tb_product` (
  `pro_id` varchar(20) NOT NULL,
  `pro_name` varchar(50) DEFAULT NULL,
  `pro_price` double DEFAULT NULL,
  `pro_info` varchar(500) DEFAULT NULL,
  `pro_image` varchar(50) DEFAULT NULL,
  `pro_subinfo` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tb_product`
--

INSERT INTO `tb_product` (`pro_id`, `pro_name`, `pro_price`, `pro_info`, `pro_image`, `pro_subinfo`) VALUES
('PRO001', 'ครัวซองต์เนยสด', 65, 'ครัวซองต์พรีเมียม ใช้เนยแท้นำเข้า อบจนแป้งกรอบนอกนุ่มใน เป็นชั้นสวยงาม หอมกลิ่นเนยชัดเจน', 'img_1777018684.jpg', 'หอมเนยแท้จากฝรั่งเศส อบสดใหม่ทุกวัน'),
('PRO002', 'พุดดิ้งคัสตาร์ด', 45, 'พุดดิ้งไข่สูตรเข้มข้น เนื้อสัมผัสเด้งนุ่ม รสชาติหวานกำลังดี ราดด้วยซอสคาราเมลเคี่ยวเอง หอมละมุน', 'img_1777018674.jpg', 'เนื้อเนียนนุ่ม ละลายในปาก พร้อมซอสคาราเมล'),
('PRO003', 'คุกกี้ช็อกโกแลตชิพ', 35, 'คุกกี้กรอบนอกนุ่มใน อัดแน่นด้วยช็อกโกแลตชิพคุณภาพดี ให้รสชาติหวานมัน เหมาะสำหรับทานคู่กับนม', 'img_1777018666.jpg', 'คุกกี้เนยสด ช็อกโกแลตชิพจัดเต็ม เคี้ยวเพลิน'),
('PRO004', 'ขนมปังกระเทียม', 85, 'ขนมปังเนื้อนุ่ม สอดไส้ครีมชีสปรุงรสพิเศษ ทาด้วยเนยกระเทียมสูตรเข้มข้น อบจนหอมฟุ้งสไตล์เกาหลี', 'img_1777018657.jpg', 'ครีมชีสเน้นๆ หอมกระเทียมและพาร์สลีย์'),
('PRO005', 'ชีสเค้ก', 120, 'ชีสเค้กสไตล์หน้าไหม้ (Basque Cheesecake) ใช้ครีมชีสเกรดพรีเมียม รสชาติเข้มข้น หวานน้อยอมเปรี้ยวเล็กน้อย', 'img_1777018641.jpg', 'ชีสเค้กหน้าไหม้ เนื้อเนียน ละมุนลิ้น'),
('PRO006', 'แอปเปิ้ลเอนวี่', 89, 'แอปเปิ้ลสายพันธุ์ Envy นำเข้า เนื้อแน่น กรอบนาน รสชาติหวานฉ่ำ ผิวสวย เหมาะสำหรับทานสด', 'img_1777018629.jpg', 'หวาน กรอบ กลิ่นหอมเป็นเอกลักษณ์'),
('PRO007', 'อะโวคาโด', 75, 'อะโวคาโดพันธุ์ดี คัดเฉพาะลูกที่แก่จัด เนื้อแน่นมันเข้มข้น อุดมด้วยไขมันดีและวิตามิน', 'img_1777018620.jpg', 'พันธุ์แฮส เนื้อเหนียว มัน เหมือนเนย'),
('PRO008', 'บรอกโคลี', 40, 'บรอกโคลีสด ดอกแน่น สีเขียวเข้ม คัดจากฟาร์มที่ได้รับมาตรฐาน เหมาะสำหรับผัดหรือลวก', 'img_1777018612.jpg', 'ผักสดเกรดพรีเมียม สะอาด ปลอดสารพิษ'),
('PRO009', 'องุ่นเขียว', 150, 'องุ่นเขียวไร้เมล็ด ลูกใหญ่ ผิวตึง รสชาติหวานหอมคล้ายดอกไม้ เนื้อเยลลี่ ทานได้ทั้งเปลือก', 'img_1777018596.jpg', 'ไซน์มัสแคท ไร้เมล็ด หวานกรอบ'),
('PRO010', 'ผักกาดหอม', 30, 'ผักกาดหอมคัดสด ใบเขียวสวย ปราศจากสารเคมีตกค้าง รสชาติหวานกรอบ ไม่ขม เหมาะสำหรับทำสลัด', 'img_1777018585.jpg', 'ผักสลัดคอส สด กรอบ สะอาดจากฟาร์ม'),
('PRO011', 'เมล่อนญี่ปุ่น', 250, 'เมล่อนเกรดส่งออก เนื้อนุ่มฉ่ำน้ำ กลิ่นหอมแรง รสชาติหวานจัด คัดพิเศษทุกลูก', 'img_1777018574.jpg', 'เนื้อสีเขียว ลายตาข่ายสวย หวานฉ่ำ'),
('PRO012', 'สตรอว์เบอร์รี', 180, 'สตรอว์เบอร์รีสด รสชาติหวานอมเปรี้ยวลงตัว กลิ่นหอมละมุน อุดมด้วยวิตามินซีสูง', 'img_1777018565.jpg', 'คัดเกรดพรีเมียม ลูกใหญ่ แดงฉ่ำ'),
('PRO013', 'มะเขือเทศ', 45, 'มะเขือเทศเชอร์รี่สีแดงสด เนื้อแน่น รสชาติหวานฉ่ำ ทานเล่นได้เหมือนผลไม้ ช่วยบำรุงผิวพรรณ', 'img_1777018546.jpg', 'มะเขือเทศราชินี หวาน กรอบ ทานง่าย'),
('PRO014', 'โลชั่นบำรุงผิว', 195, 'โลชั่นสูตรเข้มข้น ซึมไวไม่เหนียวเหนอะหนะ ช่วยฟื้นฟูผิวแห้งกร้านให้กลับมาเนียนนุ่มน่าสัมผัส', 'img_1777018525.jpg', 'ผิวชุ่มชื้น ยาวนาน 24 ชั่วโมง กลิ่นหอม'),
('PRO015', 'เซรั่ม', 350, 'เซรั่มบำรุงผิวหน้าสูตรล้ำลึก ช่วยเติมเต็มความชุ่มชื้น ให้ผิวแลดูกระชับ กระจ่างใสอย่างเป็นธรรมชาติ', 'img_1777012004.jpg', 'ไฮยาลูรอนเข้มข้น ลดเลือนริ้วรอย'),
('PRO016', 'แชมพู', 150, 'แชมพูสระผมปราศจากซิลิโคนและพาราเบน อ่อนโยนต่อหนังศีรษะ ช่วยให้ผมสุขภาพดี มีน้ำหนัก', 'img_1777018516.jpg', 'สูตรออร์แกนิก ลดผมขาดหลุดร่วง'),
('PRO017', 'ครีมกันแดด', 290, 'ครีมกันแดดเนื้อบางเบา ปกป้องผิวจากรังสี UVA/UVB ได้อย่างมีประสิทธิภาพ กันน้ำ กันเหงื่อ', 'img_1777018506.jpg', 'SPF50+ PA++++ คุมมัน ไม่เป็นคราบ'),
('PRO018', 'เจลว่านหางจระเข้', 120, 'เจลว่านหางจระเข้บริสุทธิ์ ช่วยลดการระคายเคืองจากแสงแดด เติมความชุ่มชื้น ใช้ได้ทั้งผิวหน้าและตัว', 'img_1777018498.jpg', 'สารสกัดเข้มข้น 99% ปลอบประโลมผิว'),
('PRO019', 'ยาวิตามินซี', 380, 'ผลิตภัณฑ์เสริมอาหารวิตามินซีคุณภาพสูง ช่วยต่อต้านอนุมูลอิสระ บำรุงผิวพรรณ และป้องกันหวัด', 'img_1777018477.jpg', 'วิตามินซี 1000mg เสริมภูมิคุ้มกัน');

-- --------------------------------------------------------

--
-- Table structure for table `tb_tag`
--

CREATE TABLE `tb_tag` (
  `pro_id` varchar(20) NOT NULL,
  `cat_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tb_tag`
--

INSERT INTO `tb_tag` (`pro_id`, `cat_id`) VALUES
('PRO001', 'CAT001'),
('PRO002', 'CAT001'),
('PRO003', 'CAT001'),
('PRO004', 'CAT001'),
('PRO005', 'CAT001'),
('PRO006', 'CAT002'),
('PRO007', 'CAT002'),
('PRO008', 'CAT002'),
('PRO009', 'CAT002'),
('PRO010', 'CAT002'),
('PRO011', 'CAT002'),
('PRO012', 'CAT002'),
('PRO013', 'CAT002'),
('PRO014', 'CAT003'),
('PRO015', 'CAT003'),
('PRO016', 'CAT003'),
('PRO017', 'CAT003'),
('PRO018', 'CAT003'),
('PRO019', 'CAT003');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_category`
--
ALTER TABLE `tb_category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `tb_member`
--
ALTER TABLE `tb_member`
  ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `tb_order`
--
ALTER TABLE `tb_order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `tb_orderdetail`
--
ALTER TABLE `tb_orderdetail`
  ADD PRIMARY KEY (`order_id`,`member_id`,`pro_id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `pro_id` (`pro_id`);

--
-- Indexes for table `tb_product`
--
ALTER TABLE `tb_product`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `tb_tag`
--
ALTER TABLE `tb_tag`
  ADD PRIMARY KEY (`pro_id`,`cat_id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_order`
--
ALTER TABLE `tb_order`
  ADD CONSTRAINT `tb_order_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `tb_member` (`member_id`);

--
-- Constraints for table `tb_orderdetail`
--
ALTER TABLE `tb_orderdetail`
  ADD CONSTRAINT `tb_orderdetail_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `tb_order` (`order_id`),
  ADD CONSTRAINT `tb_orderdetail_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `tb_member` (`member_id`),
  ADD CONSTRAINT `tb_orderdetail_ibfk_3` FOREIGN KEY (`pro_id`) REFERENCES `tb_product` (`pro_id`);

--
-- Constraints for table `tb_tag`
--
ALTER TABLE `tb_tag`
  ADD CONSTRAINT `tb_tag_ibfk_1` FOREIGN KEY (`pro_id`) REFERENCES `tb_product` (`pro_id`),
  ADD CONSTRAINT `tb_tag_ibfk_2` FOREIGN KEY (`cat_id`) REFERENCES `tb_category` (`cat_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
