<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once "connect.php"; 

$m_id = "";
$m_name = "";

if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
    // เปลี่ยนชื่อตารางเป็น tb_member ตามฐานข้อมูลหลัก
    $sql = "SELECT member_id, firstname, lastname FROM tb_member WHERE email = '$email'";
    $res_user = mysqli_query($conn, $sql);
    
    if ($res_user && mysqli_num_rows($res_user) > 0) {
        $row_user = mysqli_fetch_assoc($res_user);
        $m_id = $row_user['member_id'];
        $m_name = $row_user['firstname'] . " " . $row_user['lastname'];
    }
}
?>
<div id="sideMenuOverlay" class="menu-overlay" onclick="closeMenu()">
    <div class="side-menu-container" onclick="event.stopPropagation()">
        <div class="options-group">
            <a href="edit.php" class="option-btn">แก้ไขข้อมูลส่วนตัว</a>
            <!-- <a href="contact.php" class="option-btn">ช่องทางการติดต่อ</a> -->
        </div>
        <div class="divider-line"></div>
        <div class="text-center"><p class="sub-heading">ติดต่อ: 061-222-3333</p></div>
        <div class="bottom-section">
            <a href="javascript:void(0)" class="logout-full-btn" onclick="openLogoutConfirm()">
                <span>ออกจากระบบ</span>
            </a>
        </div>

        <div id="userLogoutModal" class="logout-screen-overlay" style="display: none;">
            <div class="windowns">
                <div class="in-windowns">
                    <div class="content-for-windowns">คุณแน่ใจว่าจะออกจากระบบ?</div>
                    <div class="double-buttons">
                        <a href="logout_user_action.php"><button class="green-bt">ตกลง</button></a>
                        <button class="red-bt" onclick="closeLogoutConfirm()">ยกเลิก</button>
                    </div>
                </div>
            </div>
        </div>

        <script>
        // ฟังก์ชันเปิด-ปิด Side Menu (ถ้ายังไม่มี)
        function openMenu() { document.getElementById("sideMenuOverlay").style.display = "block"; }
        function closeMenu() { document.getElementById("sideMenuOverlay").style.display = "none"; }

        // ฟังก์ชันควบคุมหน้าต่างยืนยันการออกจากระบบ
        function openLogoutConfirm() {
            document.getElementById("userLogoutModal").style.display = "flex";
        }

        function closeLogoutConfirm() {
            document.getElementById("userLogoutModal").style.display = "none";
        }
        </script>
    </div>
</div>