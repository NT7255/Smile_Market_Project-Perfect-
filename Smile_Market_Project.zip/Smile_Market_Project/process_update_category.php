<?php
include "connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับค่าและป้องกัน SQL Injection
    $cat_id   = mysqli_real_escape_string($conn, $_POST['cat_id']);
    $cat_name = mysqli_real_escape_string($conn, $_POST['cat_name']);

    if ($cat_id != "" && $cat_name != "") {
        // อัปเดตข้อมูลชื่อประเภทสินค้า
        $sql_update = "UPDATE tb_category SET cat_name = '$cat_name' WHERE cat_id = '$cat_id'";

        if (mysqli_query($conn, $sql_update)) {
            echo "<script>
                    alert('แก้ไขชื่อประเภทสินค้าเรียบร้อยแล้ว'); 
                    window.location='admin_category_edit.php';
                  </script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "<script>alert('กรุณากรอกข้อมูลให้ครบถ้วน'); window.history.back();</script>";
    }
}
?>