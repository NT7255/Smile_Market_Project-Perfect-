<?php
include "connect.php";

// รับค่า cat_id และป้องกัน SQL Injection
$cat_id = mysqli_real_escape_string($conn, $_GET['cat_id']);

if ($cat_id != "") {
    
    // 1. ตรวจสอบว่ามีสินค้าตัวไหนที่ใช้ประเภทนี้อยู่หรือไม่ (เช็คจากตาราง tb_tag)
    $sql_check = "SELECT pro_id FROM tb_tag WHERE cat_id = '$cat_id' LIMIT 1";
    $res_check = mysqli_query($conn, $sql_check);

    if (mysqli_num_rows($res_check) > 0) {
        // --- กรณีมีสินค้าใช้งานประเภทนี้อยู่ ให้แจ้งเตือนและหยุดการลบ ---
        echo "<script>
                alert('ไม่สามารถลบประเภทสินค้าได้! เนื่องจากยังมีสินค้าที่ใช้งานประเภทนี้อยู่ กรุณาลบสินค้าหรือเปลี่ยนประเภทสินค้าเหล่านั้นก่อน');
                window.location.href='admin_category_edit.php';
              </script>";
        exit; // หยุดการทำงาน
    }

    // --- กรณีไม่มีสินค้าผูกอยู่ ให้ดำเนินการลบประเภทสินค้า ---
    
    // 2. ลบประเภทสินค้าออกจากตาราง tb_category
    $sql_delete = "DELETE FROM tb_category WHERE cat_id = '$cat_id'";
    
    if (mysqli_query($conn, $sql_delete)) {
        echo "<script>
                alert('ลบประเภทสินค้าเรียบร้อยแล้ว'); 
                window.location='admin_category_edit.php';
              </script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    header("Location: admin_category_edit.php");
}
?>