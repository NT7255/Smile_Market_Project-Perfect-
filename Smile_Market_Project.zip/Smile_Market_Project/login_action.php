<?php
session_start();

// ลบข้อมูลทั้งหมดใน Session ทำให้ไฟล์อื่นเรียกใช้ไม่ได้อีก
session_unset();
session_destroy();

echo "<script>alert('ออกจากระบบเรียบร้อย'); window.location='login.php';</script>";
exit();
?>