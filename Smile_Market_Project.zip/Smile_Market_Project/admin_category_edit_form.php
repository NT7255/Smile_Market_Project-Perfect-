<?php
include "connect.php";

// รับ id ประเภทสินค้าที่ต้องการแก้ไข
if (isset($_GET['cat_id'])) {
    $cat_id = mysqli_real_escape_string($conn, $_GET['cat_id']);
    
    // ดึงข้อมูลเดิมออกมา
    $sql = "SELECT * FROM tb_category WHERE cat_id = '$cat_id'";
    $res = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($res);

    if (!$row) {
        echo "<script>alert('ไม่พบข้อมูลประเภทสินค้า'); window.location='admin_category_edit.php';</script>";
        exit;
    }
} else {
    header("Location: admin_category_edit.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>แก้ไขประเภทสินค้า - <?php echo $row['cat_name']; ?></title>
    <link rel="stylesheet" href="admin_goods_add.css"> 
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="logout.css">
</head>
<body>
    <?php include "tab-above-admin.php"; ?>

    <div class="main_size" style="max-width: 600px; margin: 40px auto;">
        <div class="header-content">
            <h1>📝 แก้ไขประเภทสินค้า</h1>
            <p>รหัสประเภทสินค้า: <?php echo $row['cat_id']; ?></p>
        </div>
        <div class="line"></div>

        <form action="process_update_category.php" method="POST" class="admin-form">
            <input type="hidden" name="cat_id" value="<?php echo $row['cat_id']; ?>">

            <div class="form-group">
                <label>ชื่อประเภทสินค้า</label>
                <input type="text" name="cat_name" value="<?php echo $row['cat_name']; ?>" required class="gen-form">
            </div>

            <div class="line"></div>
            
            <div class="button-group" style="display: flex; gap: 15px; justify-content: flex-end; margin-top: 20px;">
                <button type="button" onclick="window.location='admin_category_edit.php';" class="btn-cancel" style="padding: 10px 20px; cursor: pointer;">ยกเลิก</button>
                <button type="submit" class="btn-confirm" style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer;">บันทึกการแก้ไข</button>
            </div>
        </form>
    </div>
</body>
</html>