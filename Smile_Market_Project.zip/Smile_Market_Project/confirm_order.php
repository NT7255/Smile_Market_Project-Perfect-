<?php
session_start();
include_once "connect.php";

// 1. ตรวจสอบว่ามีการส่งไฟล์สลิปมาจริงหรือไม่
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['slip_image'])) {
    
    $m_id = $_SESSION['m_id'];
    $order_date = date("Y-m-d");
    $order_status = "1"; // สถานะเริ่มต้น (เช่น รอตรวจสอบ)

    // ดึงข้อมูลสมาชิกเพื่อนำมาบันทึกลง tb_order (ตามโครงสร้าง SQL ของคุณ)
    $sql_m = "SELECT * FROM tb_member WHERE member_id = '$m_id'";
    $res_m = mysqli_query($conn, $sql_m);
    $user = mysqli_fetch_assoc($res_m);
    
    $m_name = $user['member_name'] . " " . $user['member_lastname'];
    $m_tel = $user['member_tel'];
    $m_address = $user['member_address'];

    // 2. จัดการไฟล์รูปภาพสลิป (ย้ายไป uploads/)
    $new_file_name = "";
    if ($_FILES['slip_image']['name'] != "") {
        $ext = pathinfo($_FILES['slip_image']['name'], PATHINFO_EXTENSION);
        $new_file_name = "slip_" . time() . "_" . uniqid() . "." . $ext;
        $target_path = "uploads/" . $new_file_name;
        
        move_uploaded_file($_FILES['slip_image']['tmp_name'], $target_path);
    }

    // 3. สร้าง Order ID และบันทึกลง tb_order
    $order_id = "ORD" . date("YmdHis");
    $sql_order = "INSERT INTO tb_order (order_id, member_id, member_name, member_tel, member_address, order_date, order_slip_image, order_status) 
                  VALUES ('$order_id', '$m_id', '$m_name', '$m_tel', '$m_address', '$order_date', '$new_file_name', '$order_status')";

    if (mysqli_query($conn, $sql_order)) {
        
        // 4. บันทึกรายการสินค้าลง tb_orderdetail (ดึงข้อมูลจาก SESSION)
        foreach ($_SESSION['cart'] as $pro_id => $quantity) {
            $sql_p = "SELECT pro_price FROM tb_product WHERE pro_id = '$pro_id'";
            $res_p = mysqli_query($conn, $sql_p);
            $row_p = mysqli_fetch_assoc($res_p);
            $price = $row_p['pro_price'];

            $sql_detail = "INSERT INTO tb_orderdetail (order_id, member_id, pro_id, quantity, price) 
                           VALUES ('$order_id', '$m_id', '$pro_id', '$quantity', '$price')";
            mysqli_query($conn, $sql_detail);
        }

        // 5. ล้างตะกร้าสินค้าและส่งผู้ใช้ไปหน้าแจ้งผลสำเร็จ
        unset($_SESSION['cart']);
        echo "<script>
                alert('ส่งข้อมูลการชำระเงินเรียบร้อยแล้ว!');
                window.location='homepage.php'; 
              </script>";
    } else {
        echo "เกิดข้อผิดพลาดในการบันทึกข้อมูล: " . mysqli_error($conn);
    }
} else {
    header("Location: payment.php");
}
?>