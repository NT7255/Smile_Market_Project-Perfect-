<?php
session_start();
include_once "connect.php";

date_default_timezone_set("Asia/Bangkok");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['slip_image'])) {
    
    $m_id = $_SESSION['m_id'];
    
    // --- วางตรงนี้: รับค่าราคาสุทธิที่ส่งมาจาก payment.php ---
    $total_price = $_POST['order_total_price']; 

    $order_date = date("Y-m-d H:i:s"); 
    $order_status = "1"; 

    // ดึงข้อมูลสมาชิก (คงเดิม)
    $sql_m = "SELECT * FROM tb_member WHERE member_id = '$m_id'";
    $res_m = mysqli_query($conn, $sql_m);
    $user = mysqli_fetch_assoc($res_m);
    
    $m_name = $user['member_name'] . " " . $user['member_lastname'];
    $m_tel = $user['member_tel'];
    $m_address = $user['member_address'];

    // จัดการไฟล์รูปภาพสลิป (คงเดิม)
    $new_file_name = "";
    if ($_FILES['slip_image']['name'] != "") {
        $ext = pathinfo($_FILES['slip_image']['name'], PATHINFO_EXTENSION);
        $new_file_name = "slip_" . time() . "_" . uniqid() . "." . $ext;
        $target_path = "uploads/" . $new_file_name;
        move_uploaded_file($_FILES['slip_image']['tmp_name'], $target_path);
    }

    $order_id = "ORD" . date("YmdHis");
    
    // --- แก้ไขตรงนี้: เพิ่ม order_total_price และ $total_price ลงในคำสั่ง INSERT ---
    $sql_order = "INSERT INTO tb_order (
                    order_id, 
                    member_id, 
                    member_name, 
                    member_tel, 
                    member_address, 
                    order_date, 
                    order_slip_image, 
                    order_status,
                    order_total_price
                  ) VALUES (
                    '$order_id', 
                    '$m_id', 
                    '$m_name', 
                    '$m_tel', 
                    '$m_address', 
                    '$order_date', 
                    '$new_file_name', 
                    '$order_status',
                    '$total_price'
                  )";

    if (mysqli_query($conn, $sql_order)) {
        // ส่วนบันทึกรายละเอียดสินค้า tb_orderdetail (คงเดิม)
        foreach ($_SESSION['cart'] as $pro_id => $quantity) {
            $sql_p = "SELECT pro_price FROM tb_product WHERE pro_id = '$pro_id'";
            $res_p = mysqli_query($conn, $sql_p);
            $row_p = mysqli_fetch_assoc($res_p);
            $price = $row_p['pro_price'];

            $sql_detail = "INSERT INTO tb_orderdetail (order_id, member_id, pro_id, quantity, price) 
                           VALUES ('$order_id', '$m_id', '$pro_id', '$quantity', '$price')";
            mysqli_query($conn, $sql_detail);
        }

        unset($_SESSION['cart']);
        echo "<script>
                alert('บันทึกการสั่งซื้อและยอดชำระเรียบร้อยแล้ว');
                window.location.href='notify_order.php';
              </script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>