<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="tab-menu.css">
    <!-- <style>
        .above-tab{
            z-index: 9999;
        }
    </style> -->
</head>
<body>
    <div class="above-tab">
        <!-- ปุ่มโลโก้ไปหน้าหลัก -->
        <a href="homepage.php" class="pt1"><img class="circle" src="images/smile-market-logo.PNG"></a>
        <!-- ปุ่มรถเข็น -->
        <div class="pt5">
            <a class="white-icon-button" href="cart.php" >
                <svg  xmlns="http://www.w3.org/2000/svg" width="24" height="24"  
fill="currentColor" viewBox="0 0 24 24" >
                    <path d="M21 4H6.17l-.18-1.15A1 1 0 0 0 5 2H2v2h2.14l1.87 12.15A1 1 0 0 0 7 17h12v-2H7.86l-.31-2H19c.45 0 .84-.3.96-.73l2-7A1 1 0 0 0 21 3.99Zm-2.75 7H7.24l-.77-5h13.2l-1.43 5ZM8 18a2 2 0 1 0 0 4 2 2 0 1 0 0-4m9 0a2 2 0 1 0 0 4 2 2 0 1 0 0-4"></path>
                </svg>
            </a>
        </div>
        <!-- ปุ่มแจ้งเตือนสถานะการจัดส่ง -->
        <div class="pt6">
            <a class="white-icon-button" href="notify.php" >
                <svg  xmlns="http://www.w3.org/2000/svg" width="24" height="24"  
fill="currentColor" viewBox="0 0 24 24" >
<!--Boxicons v3.0.8 https://boxicons.com | License  https://docs.boxicons.com/free-->
<path d="m21.95 8.68-2-6A1 1 0 0 0 19 2H6c-.38 0-.73.21-.89.55l-3 6s0 .03-.01.04c0 .02-.01.04-.02.07q-.06.15-.06.3V20c0 .55.45 1 1 1h18c.55 0 1-.45 1-1V8.97c0-.1-.01-.19-.05-.29ZM6.62 4h11.66l1.33 4H4.62zM20 19H4v-9h16z"></path>
                </svg>
            </a>
        </div>
    </div>
</body>
</html>
<!-------------------- สิ้นสุด แทบบน -------------------->