<?php
session_start();
include "connect.php";
$error = "";

if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM tb_member WHERE member_email = '$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['member_password']) || $password == $row['member_password']) {
            
            // เก็บข้อมูลทั้งหมดของ ID นี้ลง Session
            $_SESSION['user_data'] = $row; 
            $_SESSION['m_id'] = $row['member_id'];

            header("Location: homepage.php");
            exit();
        } else { $error = "รหัสผ่านไม่ถูกต้อง"; }
    } else { $error = "ไม่พบอีเมลในระบบ"; }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เข้าสู่ระบบ | Smile Market</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>

<div class="header-nav">
    <?php include "tab-above-user1.php"; ?>
</div>

<div class="main-wrapper">
    <div class="split-screen">
        <div class="login-side">
            <div class="form-container">
                
                <div class="welcome-header">
                    <img src="images/smile-market-logo-cutouted.png" alt="Logo" class="login-logo">
                    <h1>ยินดีต้อนรับ</h1>
                    <p class="subtitle">กรุณากรอกข้อมูลเพื่อเข้าสู่ระบบ</p>
                </div>

                <?php if(!empty($error)): ?>
                    <div class="error-banner" style="background-color: #ffebee; color: #c62828; padding: 10px; border-radius: 5px; margin-bottom: 20px; text-align: center; border: 1px solid #ef9a9a;">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="input-group">
                        <label>อีเมลหรือเบอร์โทรศัพท์</label>
                        <input type="text" name="email" placeholder="example@mail.com" required>
                    </div>

                    <div class="input-group">
                        <label>รหัสผ่าน</label>
                        <input type="password" name="password" placeholder="••••••••" required>
                    </div>

                    <div class="action-row">
                        <a href="repassword.php" class="forgot-link">ลืมรหัสผ่าน?</a>
                    </div>

                    <button type="submit" name="login" class="btn-submit">เข้าสู่ระบบ</button>
                </form>

                <p class="footer-text">
                    ยังไม่มีบัญชีสมาชิก? <a href="register.php">สมัครสมาชิกใหม่</a>
                </p>
            </div>
        </div>

        <div class="image-side">
            <div class="image-content">
                <h1>Smile Market</h1>
                <p>ช้อปปิ้งออนไลน์ง่ายๆ ได้ที่นี่</p>
            </div>
        </div>
    </div>
</div>

</body>
</html>