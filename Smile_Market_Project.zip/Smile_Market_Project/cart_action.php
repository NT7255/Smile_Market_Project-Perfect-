<?php
session_start();

if (isset($_GET['pro_id'])) {
    $p_id = $_GET['pro_id'];
    $act = isset($_GET['act']) ? $_GET['act'] : 'add';

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    switch ($act) {
        case 'add':
            // เพิ่มจำนวน
            if (isset($_SESSION['cart'][$p_id])) {
                $_SESSION['cart'][$p_id]++;
            } else {
                $_SESSION['cart'][$p_id] = 1;
            }
            break;

        case 'remove_one':
            // ลดจำนวน (ถ้าเหลือ 1 แล้วลด จะลบทิ้งเลย)
            if (isset($_SESSION['cart'][$p_id])) {
                $_SESSION['cart'][$p_id]--;
                if ($_SESSION['cart'][$p_id] <= 0) {
                    unset($_SESSION['cart'][$p_id]);
                }
            }
            break;

        case 'remove_all':
            // ลบสินค้าตัวนี้ออกจากรถเข็นทันที
            unset($_SESSION['cart'][$p_id]);
            break;
    }
}

// เมื่อจัดการเสร็จแล้ว ให้เด้งกลับไปที่หน้ารถเข็นเดิม
header("Location: cart.php");
exit();
?>