<?php
session_start();
session_unset();    // ล้างตัวแปร Session ทั้งหมด
session_destroy();  // ทำลาย Session ในระบบ
header("Location: login.php"); // ส่งกลับไปหน้า Login
exit();
?>