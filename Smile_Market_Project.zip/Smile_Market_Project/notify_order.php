<?php
session_start();
include "connect.php"; 
date_default_timezone_set("Asia/Bangkok");

// ตรวจสอบ ID ผู้ใช้
$current_m_id = isset($_SESSION['m_id']) ? $_SESSION['m_id'] : "";
if(empty($current_m_id)){ 
    header("Location: login.php"); 
    exit(); 
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>สถานะการสั่งซื้อของฉัน</title>
    <link rel="stylesheet" href="yellow_bg.css">
    <link rel="stylesheet" href="logout.css">
    <style>
        .status-badge { padding: 5px 12px; border-radius: 20px; font-size: 0.85em; font-weight: bold; }
        .wait { background: #FFC107; color: #000; } 
        .done { background: #4CAF50; color: #fff; }
        
        .order-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .order-table th { 
            position: sticky; top: 80px; background: #eee; padding: 12px; z-index: 10;
            border-bottom: 2px solid #333; text-align: left;
        }
        .order-table td { padding: 15px; border-bottom: 1px solid #ddd; }
        .order-row:hover { background-color: #f9f9f9; }
        .reject { background: #f44336; color: #fff; } /* สีแดงสำหรับสถานะปฏิเสธ */
        .reason-text { color: #f44336; font-size: 0.85em; display: block; margin-top: 5px; font-style: italic; }
    </style>
</head>
<body class="yellow_bg">
    <?php include "tab-above-user2.php"; ?>
    <div class="main_size2 start-padding">
        <h3>🔔 การแจ้งเตือนติดตามสถานะการสั่งซื้อ</h3>
        <table class="order-table">
            <thead>
                <tr>
                    <th>เลขที่สั่งซื้อ</th>
                    <th>วันที่/เวลาสั่งซื้อ</th>
                    <th>ยอดชำระ</th> <th>สถานะ</th>
                    <th>รายละเอียด</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($conn) {
                    $sql = "SELECT * FROM tb_order WHERE member_id = '$current_m_id' ORDER BY order_date DESC";
                    $result = mysqli_query($conn, $sql);
                    
                    if($result && mysqli_num_rows($result) > 0){
                        while($row = mysqli_fetch_assoc($result)){
                            $status_text = ($row['order_status'] == '1') ? "รอยืนยัน" : "ยืนยันแล้ว";
                            $status_class = ($row['order_status'] == '1') ? "wait" : "done";
                            $order_time = date("d/m/Y H:i", strtotime($row['order_date']));
                ?>
                <?php
                    $status_text = "ไม่ระบุ";
                    $status_class = "";
                    
                    if($row['order_status'] == '1') {
                        $status_text = "รอยืนยัน";
                        $status_class = "wait";
                    } elseif($row['order_status'] == '2') {
                        $status_text = "ยืนยันแล้ว";
                        $status_class = "done";
                    } elseif($row['order_status'] == '3') {
                        $status_text = "ถูกปฏิเสธ";
                        $status_class = "reject";
                    }
                ?>
                <tr class="order-row">
                    <td><?php echo $row['order_id']; ?></td>
                    <td><?php echo $order_time; ?> น.</td>
                    <td>฿<?php echo number_format($row['order_total_price'] ?? 0, 2); ?></td>
                    <td>
                        <span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                        <?php if($row['order_status'] == '3' && !empty($row['order_remark'])): ?>
                            <span class="reason-text">หมายเหตุ: <?php echo $row['order_remark']; ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="order_detail_view.php?order_id=<?php echo $row['order_id']; ?>">📂 ดูรายการ</a>
                    </td>
                </tr>
                <?php 
                        }
                    } else {
                        // แก้ไข colspan เป็น 5 เพื่อให้คลุมทั้งตาราง
                        echo "<tr><td colspan='5' style='text-align:center; padding:30px; color:#888;'>ยังไม่มีรายการสั่งซื้อ</td></tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>