<?php
session_start();
// 1. ต้องเชื่อมต่อฐานข้อมูลก่อนการใช้งาน $conn ในบรรทัดอื่นๆ
include_once "connect.php";

// ตั้งค่า Timezone ให้ตรงกับไทย เพื่อแสดงเวลาปัจจุบันได้ถูกต้อง
date_default_timezone_set("Asia/Bangkok");

// อัปเดตสถานะเมื่อกดปุ่ม ยืนยันการชำระเงิน
if(isset($_GET['action']) && $_GET['action'] == 'confirm' && isset($_GET['order_id'])){
    $id = mysqli_real_escape_string($conn, $_GET['order_id']);
    $sql_update = "UPDATE tb_order SET order_status = '2' WHERE order_id = '$id'"; 
    if(mysqli_query($conn, $sql_update)){
        echo "<script>alert('ยืนยันรายการเรียบร้อย'); window.location='admin_notify.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ระบบจัดการคำสั่งซื้อ - Admin</title>
    <link rel="stylesheet" href="yellow_bg.css">
    <style>
        /* ปรับให้หน้าเว็บยืดหยุ่น ไม่จำกัดความสูง */
        .table-container {
            max-height: none !important; 
            overflow: visible !important; 
            margin-top: 20px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        .order-table { width: 100%; border-collapse: collapse; }

        /* หัวตาราง Sticky อยู่ใต้เมนู (ปรับ top ตามความสูงเมนูจริง เช่น 80px) */
        .order-table thead th { 
            position: sticky; 
            top: 80px; 
            background: #eeeeee; 
            z-index: 10; 
            padding: 15px;
            border-bottom: 2px solid #ddd;
            text-align: left;
        }

        .order-table td { padding: 12px; border-bottom: 1px solid #eee; }
        
        .btn-view { background: #2196F3; color: white; padding: 6px 12px; text-decoration: none; border-radius: 4px; font-size: 14px; }
        .btn-confirm { background: #4CAF50; color: white; padding: 6px 12px; text-decoration: none; border-radius: 4px; font-size: 14px; }
    </style>
</head>
<body class="yellow_bg">
    <?php include "tab-above-admin.php"; ?>
    <div class="main_size2 start-padding">
        <h2>รายการรอตรวจสอบการชำระเงิน</h2>
        <div class="table-container">
            <table class="order-table">
                <thead>
                    <tr>
                        <th>เลขที่สั่งซื้อ</th>
                        <th>ชื่อลูกค้า</th>
                        <th>วันที่/เวลาสั่งซื้อ</th>
                        <th>สลิป</th>
                        <th>จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // ตรวจสอบตัวแปร $conn อีกครั้งก่อน Query
                    if ($conn) {
                        $sql = "SELECT * FROM tb_order WHERE order_status = '1' ORDER BY order_date DESC";
                        $result = mysqli_query($conn, $sql);
                        
                        if(mysqli_num_rows($result) > 0){
                            while($row = mysqli_fetch_assoc($result)){
                                // แสดงผลวันที่และเวลา
                                $order_time = date("d/m/Y H:i", strtotime($row['order_date']));
                    ?>
                    <tr>
                        <td><?php echo $row['order_id']; ?></td>
                        <td><?php echo $row['member_name']; ?></td>
                        <td><?php echo $order_time; ?> น.</td>
                        <td>
                            <?php if(!empty($row['order_slip_image'])){ ?>
                                <a href="uploads/<?php echo $row['order_slip_image']; ?>" target="_blank" class="btn-view">👁️ ดูสลิป</a>
                            <?php } else { echo "ไม่มีหลักฐาน"; } ?>
                        </td>
                        <td>
                            <a href="?action=confirm&order_id=<?php echo $row['order_id']; ?>" 
                               onclick="return confirm('ยืนยันการรับเงินรายการนี้?')" class="btn-confirm">✅ ยืนยัน</a>
                        </td>
                    </tr>
                    <?php 
                            }
                        } else {
                            echo "<tr><td colspan='5' style='text-align:center; padding:20px;'>ไม่มีรายการรอตรวจสอบ</td></tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>