<?php
session_start();
include "connect.php"; 
date_default_timezone_set("Asia/Bangkok");

// --- ส่วนที่เพิ่ม/แก้ไข: จัดการการยืนยันและปฏิเสธ ---
if(isset($_GET['action']) && isset($_GET['order_id'])){
    $id = mysqli_real_escape_string($conn, $_GET['order_id']);
    
    if($_GET['action'] == 'confirm'){
        // ยืนยันการชำระเงิน (status = 2)
        $sql_update = "UPDATE tb_order SET order_status = '2', order_remark = NULL WHERE order_id = '$id'"; 
        if(mysqli_query($conn, $sql_update)){
            echo "<script>alert('ยืนยันรายการเรียบร้อย'); window.location='admin_notify.php';</script>";
        }
    } 
    elseif($_GET['action'] == 'reject' && isset($_POST['reason'])){
        // ปฏิเสธการชำระเงิน (status = 3 หรือตามที่คุณกำหนด) และบันทึกเหตุผล
        $reason = mysqli_real_escape_string($conn, $_POST['reason']);
        $sql_reject = "UPDATE tb_order SET order_status = '3', order_remark = '$reason' WHERE order_id = '$id'";
        if(mysqli_query($conn, $sql_reject)){
            echo "<script>alert('ปฏิเสธรายการเรียบร้อย'); window.location='admin_notify.php';</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ระบบจัดการคำสั่งซื้อ - Admin</title>
    <link rel="stylesheet" href="yellow_bg.css">
    <link rel="stylesheet" href="logout.css">
    <style>
        .table-container {
            max-height: none !important; 
            overflow: visible !important; 
            margin-top: 20px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        .order-table { width: 100%; border-collapse: collapse; }
        .order-table thead th { 
            position: sticky; 
            top: 80px; 
            background: #eeeeee; 
            z-index: 10; 
            padding: 15px;
            border-bottom: 2px solid #ddd;
            text-align: left;
        }
        .order-table td { padding: 12px; border-bottom: 1px solid #eee; }
        .btn-view { background: #2196F3; color: white; padding: 6px 12px; text-decoration: none; border-radius: 4px; font-size: 14px; }
        .btn-confirm { background: #4CAF50; color: white; padding: 6px 12px; text-decoration: none; border-radius: 4px; font-size: 14px; }
        .price-text { color: #d32f2f; font-weight: bold; } /* สีแดงสำหรับยอดเงิน */
        .btn-confirm { background: #4CAF50; color: white; padding: 6px 12px; text-decoration: none; border-radius: 4px; display: inline-block; margin-bottom: 5px; }
        .btn-reject { background: #f44336; color: white; padding: 6px 12px; text-decoration: none; border-radius: 4px; cursor: pointer; border: none; }
        
        /* Modal Style */
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); }
        .modal-content { background: white; margin: 15% auto; padding: 20px; border-radius: 8px; width: 300px; text-align: center; }
    </style>
</head>
<body class="yellow_bg">
    <?php include "tab-above-admin.php"; ?>
    <div class="main_size2 start-padding">
        <h2>แจ้งเตือนการตรวจสอบการชำระเงิน</h2>
        <div class="table-container">
            <table class="order-table">
                <thead>
                    <tr>
                        <th>เลขที่สั่งซื้อ</th>
                        <th>ชื่อลูกค้า</th>
                        <th>รายการสินค้า</th> <th>ยอดชำระ</th>
                        <th>สลิป</th>
                        <th>จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM tb_order WHERE order_status = '1' ORDER BY order_date DESC";
                    $result = mysqli_query($conn, $sql);
                    
                    if(mysqli_num_rows($result) > 0) {
                        while($row = mysqli_fetch_assoc($result)){
                            $current_order_id = $row['order_id'];
                    ?>
                    <tr>
                        <td><?php echo $row['order_id']; ?></td>
                        <td><?php echo $row['member_name']; ?></td>
                        
                        <td style="font-size: 0.9em; text-align: left; vertical-align: top;">
                            <ul style="margin: 0; padding-left: 15px; list-style-type: circle;">
                            <?php
                                // ดึงชื่อสินค้าและจำนวนจากตารางรายละเอียด
                                $sql_items = "SELECT d.quantity, p.pro_name 
                                              FROM tb_orderdetail d
                                              JOIN tb_product p ON d.pro_id = p.pro_id
                                              WHERE d.order_id = '$current_order_id'";
                                $res_items = mysqli_query($conn, $sql_items);
                                while($item = mysqli_fetch_assoc($res_items)){
                                    echo "<li>" . $item['pro_name'] . " (x" . $item['quantity'] . ")</li>";
                                }
                            ?>
                            </ul>
                        </td>

                        <td style="font-weight: bold; color: #d32f2f;">
                            ฿<?php echo number_format($row['order_total_price'] ?? 0, 2); ?>
                        </td>
                        <td>
                            <?php if(!empty($row['order_slip_image'])){ ?>
                                <a href="uploads/<?php echo $row['order_slip_image']; ?>" target="_blank" class="btn-view">👁️ ดูสลิป</a>
                            <?php } else { echo "ไม่มีหลักฐาน"; } ?>
                        </td>
                        <td>
                            <a href="?action=confirm&order_id=<?php echo $row['order_id']; ?>" 
                               onclick="return confirm('ยืนยันการรับเงินรายการนี้?')" class="btn-confirm" style="display:inline-block; margin-bottom:5px;">✅ ยืนยัน</a>
                            <br>
                            <button class="btn-reject" onclick="openRejectModal('<?php echo $row['order_id']; ?>')">❌ ปฏิเสธ</button>
                        </td>
                    </tr>
                    <?php 
                        } 
                    } else {
                        echo "<tr><td colspan='6' style='text-align:center; padding:20px;'>ไม่มีรายการรอตรวจสอบ</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <h4>ระบุเหตุผลที่ปฏิเสธ</h4>
            <form id="rejectForm" method="POST">
                <textarea name="reason" placeholder="เช่น สลิปไม่ถูกต้อง, ยอดเงินไม่ครบ" required></textarea>
                <button type="submit" class="btn-confirm">ตกลง</button>
                <button type="button" class="btn-reject" onclick="closeModal()">ยกเลิก</button>
            </form>
        </div>
    </div>

    <script>
    function openRejectModal(orderId) {
        document.getElementById('rejectForm').action = "?action=reject&order_id=" + orderId;
        document.getElementById('rejectModal').style.display = "block";
    }
    function closeModal() {
        document.getElementById('rejectModal').style.display = "none";
    }
    </script>
</body>