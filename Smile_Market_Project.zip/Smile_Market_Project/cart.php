<?php
session_start();
include "connect.php"; // ตรวจสอบว่ามีไฟล์เชื่อมต่อฐานข้อมูล

// เตรียมตัวแปรสำหรับยอดรวม
$total_price = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ตะกร้าสินค้า</title>
    <link rel="stylesheet" href="cart.css">
    <link rel="stylesheet" href="main.css">
</head>
<body>
    <?php include "tab-above-user2.php"; ?>

    <div class="start-heading">รถเข็นของฉัน</div>

    <main class="cart-container <?php echo (!empty($_SESSION['cart'])) ? 'has-items' : ''; ?>">
        
        <?php if (empty($_SESSION['cart'])): ?>
            <div class="cart-empty">
                <h2>รถเข็นว่างเปล่า</h2>
                <p>เลือกซื้อสินค้าที่คุณชอบได้ที่หน้าหลัก</p>
                <a href="homepage.php" style="display:inline-block; margin-top:20px; padding:10px 20px; background:#FF8A00; color:white; text-decoration:none; border-radius:8px;">กลับไปช้อปปิ้ง</a>
            </div>
        <?php else: ?>

            <div class="cart-list">
                <?php
                foreach ($_SESSION['cart'] as $p_id => $qty) {
                    // ดึงข้อมูลสินค้าจากฐานข้อมูลตาม ID
                    $sql = "SELECT * FROM tb_product WHERE pro_id = '$p_id'";
                    $query = mysqli_query($conn, $sql);
                    $row = mysqli_fetch_array($query);

                    $sum = $row['pro_price'] * $qty; // ราคารวมต่อรายการ
                    $total_price += $sum; // สะสมราคารวมทั้งตะกร้า
                ?>
                <div class="cart-item">
                    <div class="item-image">
                        <img src="images/goods/<?php echo $row['pro_image']; ?>" alt="<?php echo $row['pro_name']; ?>">
                    </div>
                    <div class="item-info">
                        <h3 class="item-name"><?php echo $row['pro_name']; ?></h3>
                        <p class="item-price">฿<?php echo number_format($row['pro_price'], 2); ?></p>
                    </div>
                    
                    <div class="item-qty">
                        <a href="cart_action.php?pro_id=<?php echo $p_id; ?>&act=remove_one" class="qty-btn" style="text-decoration:none;">-</a>
                        <span class="qty-number"><?php echo $qty; ?></span>
                        <a href="cart_action.php?pro_id=<?php echo $p_id; ?>&act=add" class="qty-btn" style="text-decoration:none;">+</a>
                    </div>

                    <a href="cart_action.php?pro_id=<?php echo $p_id; ?>&act=remove_all" class="remove-btn" onclick="return confirm('ยืนยันการลบสินค้า?')">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M17 6V4c0-1.1-.9-2-2-2H9c-1.1 0-2 .9-2 2v2H2v2h2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8h2V6zM9 4h6v2H9zM6 20V8h12v12z"></path>
                        </svg> ลบ
                    </a>
                </div>
                <?php } ?>
            </div>

            <div class="cart-summary" style="margin-top: 30px; border-top: 2px solid #eee; padding-top: 20px;">
                <div style="display: flex; justify-content: space-between; font-size: 20px; font-weight: bold;">
                    <span>ยอดรวมทั้งสิ้น:</span>
                    <span style="color: #FF8A00;">฿<?php echo number_format($total_price, 2); ?></span>
                </div>

                <div style="margin-top: 20px; display: flex; justify-content: flex-end; gap: 15px; align-items: center;">
                    <a href="homepage.php" class="small-button-or3" style="text-decoration:none;">
                        เลือกสินค้าเพิ่ม
                    </a>
                    <a class="small-button-or2" href="payment.php" style="text-decoration:none;">
                        สั่งซื้อสินค้า
                    </a>
                </div>
            </div>

        <?php endif; ?>
    </main>
</body>
</html>