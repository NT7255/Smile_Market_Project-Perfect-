<?php
session_start();

// ตรวจสอบว่ามี Session m_id หรือไม่ หากไม่มีให้กลับไปหน้า Login
if (!isset($_SESSION['m_id']) || $_SESSION['login_status'] !== true) {
    header("Location: login.php");
    exit();
}

include "connect.php";

// --- ส่วนที่เพิ่ม/แก้ไข: รับค่าการค้นหาและหมวดหมู่ ---
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, trim($_GET['search'])) : "";
$current_cat = isset($_GET['cat_id']) ? mysqli_real_escape_string($conn, $_GET['cat_id']) : "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smile Market - หน้าแรก</title>
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="tab-menu.css">
    <link rel="stylesheet" href="logout.css">
    <style>
        .ads img { width: 100%; height: auto; }
        .main_size { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .category { display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 20px; }
        .cate_bt { 
            padding: 8px 18px; background-color: white; border: 1px solid #ddd; 
            border-radius: 20px; cursor: pointer; transition: 0.3s; 
        }
        .cate_bt:hover { background-color: #f0f0f0; }
        .cate_bt.active { 
            background-color: #FF8A00 !important; 
            color: white !important; 
            border-color: #FF8A00 !important; 
        }
        .goods_cate { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 20px; margin-top: 20px; }
        .goods { border: 1px solid #eee; border-radius: 8px; overflow: hidden; background: white; transition: 0.3s; }
        .goods:hover { box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .goods_img { width: 100%; height: 200px; object-fit: cover; }
        .goods_info { padding: 15px; }
        .sub-heading { font-size: 16px; font-weight: bold; margin: 0 0 10px 0; color: #333; }
        .price { font-size: 18px; color: #FF8A00; font-weight: bold; margin: 0 0 15px 0; }
        .add-hp-button-or2 { 
            width: 100%; padding: 10px; background-color: #FF8A00; color: white; 
            border: none; border-radius: 4px; cursor: pointer; font-weight: bold; 
        }
        .line { border-top: 1px solid #eee; margin: 20px 0; }
    </style>
</head>
<body>
    <?php include "tab-above-homepage.php"; ?> 

    <div class="main_size">
        <div class="category">
            <a href="homepage.php" style="text-decoration:none;">
                <button class="cate_bt <?php echo ($current_cat == '') ? 'active' : ''; ?>">ทั้งหมด</button>
            </a>
            <?php
            $res_btn = mysqli_query($conn, "SELECT * FROM tb_category");
            if ($res_btn) {
                while($btn = mysqli_fetch_array($res_btn)) {
                    $active_class = ($current_cat == $btn['cat_id']) ? 'active' : '';
                    echo '<a href="homepage.php?cat_id='.$btn['cat_id'].'" style="text-decoration:none;">
                            <button class="cate_bt '.$active_class.'">'.$btn['cat_name'].'</button>
                          </a>';
                }
            }
            ?>
        </div>

        <div class="line"></div>

        <?php if ($search != ""): ?>
            <div style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
                <h3>ผลการค้นหาสำหรับ: <span style="color: #FF8A00;">"<?php echo htmlspecialchars($search); ?>"</span></h3>
                <a href="homepage.php" style="color: #666; text-decoration: none; font-size: 14px;">✕ ล้างการค้นหา</a>
            </div>
        <?php endif; ?>

        <div class="goods_cate">
            <?php
            // --- แก้ไข SQL Query ให้รองรับทั้ง Search และ Category ---
            $sql_pro = "SELECT p.* FROM tb_product p ";
            $sql_pro .= " LEFT JOIN tb_tag t ON p.pro_id = t.pro_id ";
            $sql_pro .= " WHERE 1=1 ";

            if ($search != "") {
                $sql_pro .= " AND (p.pro_id LIKE '%$search%' OR p.pro_name LIKE '%$search%') ";
            }

            if ($current_cat != "") {
                $sql_pro .= " AND t.cat_id = '$current_cat' ";
            }

            $sql_pro .= " GROUP BY p.pro_id ORDER BY p.pro_id DESC";
            
            $res_pro = mysqli_query($conn, $sql_pro);

            if($res_pro && mysqli_num_rows($res_pro) > 0) {
                while($product = mysqli_fetch_array($res_pro)) {
                    ?>
                    <div class="goods">
                        <a href="detail_template.php?pro_id=<?php echo $product['pro_id']; ?>" style="text-decoration:none;">
                            <img class="goods_img" src="images/goods/<?php echo $product['pro_image']; ?>" 
                                 onerror="this.src='images/goods/default.jpg'">
                        </a>
                        <div class="goods_info">
                            <a href="detail_template.php?pro_id=<?php echo $product['pro_id']; ?>" style="text-decoration:none;">
                                <p class="sub-heading">
                                    <span style="color: #888; font-size: 13px;">[<?php echo $product['pro_id']; ?>]</span><br>
                                </p>
                            </a>
                            <a href="detail_template.php?pro_id=<?php echo $product['pro_id']; ?>" style="text-decoration:none;">
                                <p class="sub-heading"><?php echo $product['pro_name']; ?></p>
                            </a>
                            <p class="short-detail" style="font-size: 12px; color: #666; margin: 5px 0; height: 34px; overflow: hidden;">
                                <?php echo $product['pro_subinfo'] ?? 'รายละเอียดสินค้าเบื้องต้น...'; ?>
                            </p>
                            <p class="price">฿<?php echo number_format($product['pro_price'], 2); ?></p>
                            <a href="cart_action.php?pro_id=<?php echo $product['pro_id']; ?>&act=add" style="text-decoration:none;">
                                <button class="add-hp-button-or2">+ เพิ่ม</button>
                            </a>
                        </div>
                    </div>
                    <?php 
                }
            } else {
                echo "<div style='grid-column: 1/-1; text-align:center; color:#888; padding: 50px 0;'>";
                echo "<p>--- ไม่พบสินค้าที่คุณค้นหา ---</p>";
                echo "</div>";
            }
            ?>
        </div>
    </div>

    <?php include "tab-menu.php"; ?>
</body>
</html>