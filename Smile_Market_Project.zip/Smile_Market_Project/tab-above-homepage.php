<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="main.css">
    <!-- <style>
        .above-tab{
            z-index: 9999;
        }
    </style> -->
</head>
<body>
<!-------------------- เริ่มต้น แทบบน อย่าแก้ By เติ้ง -------------------->
    <div class="above-tab">
    <a href="homepage.php" class="pt1"><img class="circle" src="images/smile-market-logo.PNG"></a>
    
    <form id="search-form" class="pt2" action="homepage.php" method="GET">
        <input class="search" type="text" name="search" placeholder="ค้นหาชื่อหรือรหัสสินค้า..." 
               value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
    </form>
    
    <div class="pt3">
        <button type="submit" form="search-form" class="search-button">
            <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                <path d="M18 10c0-4.41-3.59-8-8-8s-8 3.59-8 8 3.59 8 8 8c1.85 0 3.54-.64 4.9-1.69l4.39 4.39 1.41-1.41-4.39-4.39c1.05-1.36 1.69-3.05 1.69-4.9zm-8 6c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"></path>
            </svg>
        </button>
    </div>
        <!-- ปุ่มรถเข็น -->
        <div class="pt5">
            <a class="white-icon-button" href="cart.php" >
                <svg  xmlns="http://www.w3.org/2000/svg" width="24" height="24"  
fill="currentColor" viewBox="0 0 24 24" >
                    <path d="M21 4H6.17l-.18-1.15A1 1 0 0 0 5 2H2v2h2.14l1.87 12.15A1 1 0 0 0 7 17h12v-2H7.86l-.31-2H19c.45 0 .84-.3.96-.73l2-7A1 1 0 0 0 21 3.99Zm-2.75 7H7.24l-.77-5h13.2l-1.43 5ZM8 18a2 2 0 1 0 0 4 2 2 0 1 0 0-4m9 0a2 2 0 1 0 0 4 2 2 0 1 0 0-4"></path>
                </svg>
            </a>
        </div>
        <!-- ปุ่มแจ้งเตือนสถานะการจัดส่ง -->
        <div class="pt6">
            <a class="white-icon-button" href="notify_order.php" >
                <svg  xmlns="http://www.w3.org/2000/svg" width="24" height="24"  
fill="currentColor" viewBox="0 0 24 24" >
<!--Boxicons v3.0.8 https://boxicons.com | License  https://docs.boxicons.com/free-->
<path d="m21.95 8.68-2-6A1 1 0 0 0 19 2H6c-.38 0-.73.21-.89.55l-3 6s0 .03-.01.04c0 .02-.01.04-.02.07q-.06.15-.06.3V20c0 .55.45 1 1 1h18c.55 0 1-.45 1-1V8.97c0-.1-.01-.19-.05-.29ZM6.62 4h11.66l1.33 4H4.62zM20 19H4v-9h16z"></path>
                </svg>
            </a>
        </div>
        <!-- ปุ่มบัญชีของฉัน -->
        <div class="pt7">
            <button class="big-button-or1" onclick="openMenu()">
                <svg class="profile-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24"  
fill="currentColor" viewBox="0 0 24 24" >
                    <path d="M12 6c-2.28 0-4 1.72-4 4s1.72 4 4 4 4-1.72 4-4-1.72-4-4-4m0 6c-1.18 0-2-.82-2-2s.82-2 2-2 2 .82 2 2-.82 2-2 2"></path><path d="M12 2C6.49 2 2 6.49 2 12c0 3.26 1.58 6.16 4 7.98V20h.03c1.67 1.25 3.73 2 5.97 2s4.31-.75 5.97-2H18v-.02c2.42-1.83 4-4.72 4-7.98 0-5.51-4.49-10-10-10M8.18 19.02C8.59 17.85 9.69 17 11 17h2c1.31 0 2.42.85 2.82 2.02-1.14.62-2.44.98-3.82.98s-2.69-.35-3.82-.98m9.3-1.21c-.81-1.66-2.51-2.82-4.48-2.82h-2c-1.97 0-3.66 1.16-4.48 2.82A7.96 7.96 0 0 1 4 11.99c0-4.41 3.59-8 8-8s8 3.59 8 8c0 2.29-.97 4.36-2.52 5.82"></path>
                </svg>
                <b>บัญชีชองฉัน</b>
            </button>
            <script>
            function openMenu() {
                document.getElementById("sideMenuOverlay").style.display = "block";
            }
            </script>
        </div>
    </div>
<!-------------------- สิ้นสุด แทบบน -------------------->
</body>
</html>