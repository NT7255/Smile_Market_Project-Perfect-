<?php
session_start();
include "connect.php"; 

if (isset($_POST['register'])) {
    $name     = mysqli_real_escape_string($conn, $_POST['member_name']);
    $lastname = mysqli_real_escape_string($conn, $_POST['member_lastname']);
    $tel      = mysqli_real_escape_string($conn, $_POST['member_tel']);
    $birthday = mysqli_real_escape_string($conn, $_POST['member_birthday']);
    $sex      = mysqli_real_escape_string($conn, $_POST['member_sex']); // รับค่าเป็นเลข 1 หรือ 2
    $address  = mysqli_real_escape_string($conn, $_POST['member_address']);
    $email    = mysqli_real_escape_string($conn, $_POST['member_email']);
    $password = $_POST['member_password'];
    $confirm  = $_POST['confirm_password'];
    $permis   = 1; // กำหนดให้เป็นสมาชิกทั่วไป (เลข 1) อัตโนมัติ

    if ($password != $confirm) {
        echo "<script>alert('รหัสผ่านไม่ตรงกัน'); window.history.back();</script>";
        exit();
    }

    // เข้ารหัสผ่านเพื่อความปลอดภัย
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // สร้าง ID
    $res_count = mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_member");
    $row_count = mysqli_fetch_assoc($res_count);
    $new_id = "MB" . str_pad($row_count['total'] + 1, 5, "0", STR_PAD_LEFT);

    // แก้ไขคำสั่ง SQL ให้ครอบคลุมทุกฟิลด์
    $sql = "INSERT INTO tb_member (member_id, member_email, member_password, member_tel, member_name, member_lastname, member_address, member_sex, member_birthday, member_permis) 
            VALUES ('$new_id', '$email', '$hashed_password', '$tel', '$name', '$lastname', '$address', '$sex', '$birthday', '$permis')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('สมัครสมาชิกสำเร็จ'); window.location.href='login.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ลงทะเบียนสมาชิก</title>
    <link rel="stylesheet" href="register.css">
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="yellow_bg.css">
</head>
<body class="yellow_bg">
    <?php include "tab-above-user1.php"; ?>   
    
    <div class="main_size2">
        <div class="start-heading">กรอกลงทะเบียนเพื่อสร้างบัญชีของคุณ</div>
        
        <form method="post" action="">
            <div class="zones">
                <div class="form-zone">
                    <label><b>ชื่อ</b></label>
                    <input type="text" class="gen-form" name="member_name" required>
                </div>
                <div class="form-zone">
                    <label><b>นามสกุล</b></label>
                    <input type="text" class="gen-form" name="member_lastname" required>
                </div>
            </div>

            <div class="zones">
                <div class="form-zone2">
                    <div class="sub-form-zone">
                        <label><b>เบอร์โทร</b></label>
                        <input type="text" class="small-2-forms" name="member_tel" required>
                    </div>
                    <div class="sub-form-zone">
                        <label><b>วันเกิด</b></label>
                        <input type="date" class="small-2-forms" name="member_birthday" required>
                    </div>
                </div>
                <div class="form-zone2">
                    <div class="sub-form-zone">
                        <label><b>เพศ :</b></label>
                        <div class="oneline">
                            <div class="row-radio">
                                <label><input type="radio" name="member_sex" value="1" required> ชาย</label>
                                <label><input type="radio" name="member_sex" value="2" required> หญิง</label>
                            </div>
                        </div>
                    </div>
                    <div class="sub-form-zone">
                        <label><b>สถานะ :</b></label>
                        <div class="status-options">
                            <label><input type="radio" name="member_status" value="โสด" checked> โสด</label>
                            <label><input type="radio" name="member_status" value="มีคู่สมรส"> มีคู่สมรส</label>
                            <label><input type="radio" name="member_status" value="แยกกันอยู่"> แยกกันอยู่</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="zones">
                <div class="form-zone">
                    <label><b>ที่อยู่</b></label>
                    <input class="gen-form2" name="member_address" required>
                </div>
                <div class="form-zone">
                    <label><b>ชื่ออีเมลล์</b></label>
                    <input type="email" class="gen-form" name="member_email" required>
                </div>
            </div>

            <div class="zones">
                <div class="form-zone">
                    <label><b>รหัสผ่าน</b></label>
                    <input type="password" class="gen-form" name="member_password" required>
                </div>
                <div class="form-zone">
                    <label><b>ยืนยันรหัสผ่าน</b></label>
                    <input type="password" class="gen-form" name="confirm_password" required>
                </div>
            </div>

            <div class="double-buttons">
                <button class="green-bt" type="submit" name="register"><b>ตกลง</b></button>
                <button type="button" class="red-bt" onclick="window.location.href='login.php'"><b>ยกเลิก</b></button>
            </div>
        </form>
    </div>
</body>
</html>