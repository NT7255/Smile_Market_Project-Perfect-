<?php
session_start();
include "connect.php";

// 1. ตรวจสอบการ Login และตะกร้าสินค้า
if (!isset($_SESSION['m_id'])) {
    header("Location: login.php");
    exit();
}
if (empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit();
}

$m_id = $_SESSION['m_id'];

// 2. แก้ไข Query: ดึงข้อมูลจาก tb_member โดยตรง (ไม่ต้อง JOIN tb_address)
$sql_user = "SELECT * FROM tb_member WHERE member_id = '$m_id'";
$res_user = mysqli_query($conn, $sql_user);
$user_info = mysqli_fetch_assoc($res_user);

$total_price = 0;
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ชำระเงิน | Smile Market</title>
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="cart.css">
    <style>
        .payment-wrapper { max-width: 900px; margin: 30px auto; display: grid; grid-template-columns: 1.5fr 1fr; gap: 20px; }
        .info-card { background: #fff; padding: 20px; border-radius: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-bottom: 20px; }
        .section-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 15px; }
        .edit-link { color: #FF8A00; text-decoration: none; font-size: 14px; font-weight: bold; }
        .user-detail p { margin: 8px 0; color: #555; }
        .bank-box { background: #fff8f0; border: 1px solid #ffe0b2; padding: 15px; border-radius: 10px; }
        .upload-zone { border: 2px dashed #FF8A00; padding: 20px; text-align: center; border-radius: 10px; background: #fff; }
        .btn-pay-final { width: 100%; padding: 15px; border-radius: 10px; border: none; font-size: 18px; font-weight: bold; cursor: pointer; transition: 0.3s; margin-top: 20px; }
        .btn-pay-final:disabled { background: #ccc; color: #999; }
        .btn-pay-final:enabled { background: #FF8A00; color: #fff; }
    </style>
</head>
<body>
    <?php include "tab-above-user2.php"; ?>

    <div class="payment-wrapper">
        
        <div class="left-side">
            <div class="info-card">
                <div class="section-header">
                    <h3><img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" width="20"> ข้อมูลการจัดส่ง</h3>
                    <a href="edit.php" class="edit-link">✎ แก้ไขข้อมูล</a>
                </div>
                <div class="user-detail">
                    <p><strong>ชื่อ-นามสกุล:</strong> <?php echo $user_info['member_name'] . " " . $user_info['member_lastname']; ?></p>
                    <p><strong>เบอร์โทรศัพท์:</strong> <?php echo $user_info['member_tel']; ?></p>
                    <p><strong>ที่อยู่:</strong> <?php echo !empty($user_info['member_address']) ? nl2br(htmlspecialchars($user_info['member_address'])) : "<span style='color:red;'>ยังไม่มีข้อมูลที่อยู่ กรุณาแก้ไขในหน้าโปรไฟล์</span>"; ?></p>
                    <p><strong>อีเมล:</strong> <?php echo $user_info['member_email']; ?></p>
                </div>
            </div>

            <div class="info-card">
                <h3>รายการสินค้า</h3>
                <?php 
                foreach ($_SESSION['cart'] as $p_id => $qty) {
                    $sql_p = "SELECT * FROM tb_product WHERE pro_id = '$p_id'";
                    $res_p = mysqli_query($conn, $sql_p);
                    $item = mysqli_fetch_array($res_p);
                    $subtotal = $item['pro_price'] * $qty;
                    $total_price += $subtotal;
                ?>
                <div style="display: flex; gap: 15px; margin-bottom: 15px; align-items: center;">
                    <img src="images/goods/<?php echo $item['pro_image']; ?>" width="60" height="60" style="border-radius: 8px; object-fit: cover;">
                    <div style="flex: 1;">
                        <p style="margin: 0; font-weight: 500;"><?php echo $item['pro_name']; ?></p>
                        <p style="margin: 0; color: #888; font-size: 13px;">฿<?php echo number_format($item['pro_price'], 2); ?> x <?php echo $qty; ?></p>
                    </div>
                    <p style="font-weight: bold;">฿<?php echo number_format($subtotal, 2); ?></p>
                </div>
                <?php } ?>
            </div>
        </div>

        <div class="right-side">
            <div class="info-card bank-box">
                <h4 style="margin-top: 0;">🏦 ข้อมูลการโอนเงิน</h4>
                <p style="font-size: 14px;">ธนาคาร: <strong>Kanit</strong><br>
                เลขบัญชี: <strong>123-4-56789-0</strong><br>
                ชื่อบัญชี: <strong>Smile Market</strong></p>
                <hr style="border: 0.5px solid #ffe0b2;">
                <div style="display: flex; justify-content: space-between; font-size: 18px; font-weight: bold;">
                    <span>ยอดที่ต้องชำระ:</span>
                    <span style="color: #FF8A00;">฿<?php echo number_format($total_price, 2); ?></span>
                </div>
            </div>

            <form action="confirm_order.php" method="POST" enctype="multipart/form-data">
                <div class="upload-zone">
                    <p style="margin-bottom: 10px; font-weight: 500;">แนบสลิปโอนเงิน</p>
                    <input type="file" name="slip_image" id="slip_image" required onchange="validatePayment()">
                    <img id="preview" style="max-width: 100%; margin-top: 10px; border-radius: 8px; display: none;">
                </div>

                <button type="submit" id="payBtn" class="btn-pay-final" disabled>ยืนยันและส่งคำสั่งซื้อ</button>
            </form>
        </div>

    </div>

    <script>
    function validatePayment() {
        const fileInput = document.getElementById('slip_image');
        const btn = document.getElementById('payBtn');
        const preview = document.getElementById('preview');

        if (fileInput.files && fileInput.files[0]) {
            btn.disabled = false;
            // แสดงตัวอย่างรูป
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            }
            reader.readAsDataURL(fileInput.files[0]);
        } else {
            btn.disabled = true;
            preview.style.display = 'none';
        }
    }
    </script>
</body>
</html>