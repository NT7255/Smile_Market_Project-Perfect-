<!-------------------- เริ่มต้น แทบบน อย่าแก้ By เติ้ง -------------------->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="admin_homepage.css">
    <link rel="stylesheet" href="main.css">
    <style>
        .above-tab{
            z-index: 9999;
        }
    </style>
</head>
<body>
    <div class="above-tab">
        <!-- ปุ่มโลโก้ไปหน้าหลัก -->
        <a href="admin_homepage.php" class="pt1"><img class="circle" src="images/smile-market-logo.PNG"></a>

        <div class="pt6">
            <a class="white-icon-button" href="admin_notify.php" >
                <svg  xmlns="http://www.w3.org/2000/svg" width="24" height="24"  
fill="currentColor" viewBox="0 0 24 24" >
<!--Boxicons v3.0.8 https://boxicons.com | License  https://docs.boxicons.com/free-->
<path d="m21.95 8.68-2-6A1 1 0 0 0 19 2H6c-.38 0-.73.21-.89.55l-3 6s0 .03-.01.04c0 .02-.01.04-.02.07q-.06.15-.06.3V20c0 .55.45 1 1 1h18c.55 0 1-.45 1-1V8.97c0-.1-.01-.19-.05-.29ZM6.62 4h11.66l1.33 4H4.62zM20 19H4v-9h16z"></path>
                </svg>
            </a>
        </div>
    </div>
</body>
</html>
<!-------------------- สิ้นสุด แทบบน -------------------->