<?php
include "connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pro_id      = mysqli_real_escape_string($conn, $_POST['pro_id']);
    $pro_name    = mysqli_real_escape_string($conn, $_POST['pro_name']);
    $pro_subinfo = mysqli_real_escape_string($conn, $_POST['pro_subinfo']);
    $pro_price   = mysqli_real_escape_string($conn, $_POST['pro_price']);
    $pro_info    = mysqli_real_escape_string($conn, $_POST['pro_info']);
    $cat_id      = mysqli_real_escape_string($conn, $_POST['cat_id']); // รับค่าประเภทสินค้า

    // 1. จัดการเรื่องรูปภาพ
    $file_name = $_FILES['pro_image']['name'];
    if ($file_name != "") {
        // ถ้ามีการอัปโหลดรูปใหม่
        $ext = pathinfo($file_name, PATHINFO_EXTENSION);
        $new_image_name = "img_" . time() . "." . $ext;
        move_uploaded_file($_FILES['pro_image']['tmp_name'], "images/goods/" . $new_image_name);
        
        // ดึงชื่อรูปเก่ามาเพื่อลบทิ้ง
        $res_old = mysqli_query($conn, "SELECT pro_image FROM tb_product WHERE pro_id = '$pro_id'");
        $old_data = mysqli_fetch_array($res_old);
        if($old_data['pro_image'] != "" && $old_data['pro_image'] != "default.jpg" && file_exists("images/goods/".$old_data['pro_image'])) {
            unlink("images/goods/".$old_data['pro_image']);
        }

        $sql_img = ", pro_image = '$new_image_name'";
    } else {
        $sql_img = ""; // ไม่เปลี่ยนรูป
    }

    // 2. Update ข้อมูลหลักในตาราง tb_product
    $sql_update_pro = "UPDATE tb_product SET 
                       pro_name = '$pro_name', 
                       pro_price = '$pro_price', 
                       pro_info = '$pro_info', 
                       pro_subinfo = '$pro_subinfo' 
                       $sql_img 
                       WHERE pro_id = '$pro_id'";

    if (mysqli_query($conn, $sql_update_pro)) {
        
        // 3. Update ประเภทสินค้า (ในตาราง tb_tag)
        // ตรวจสอบก่อนว่ามีข้อมูลใน tb_tag หรือยัง ถ้าไม่มีให้ INSERT ถ้ามีให้ UPDATE
        $check_tag = mysqli_query($conn, "SELECT * FROM tb_tag WHERE pro_id = '$pro_id'");
        if (mysqli_num_rows($check_tag) > 0) {
            $sql_tag = "UPDATE tb_tag SET cat_id = '$cat_id' WHERE pro_id = '$pro_id'";
        } else {
            $sql_tag = "INSERT INTO tb_tag (pro_id, cat_id) VALUES ('$pro_id', '$cat_id')";
        }
        
        mysqli_query($conn, $sql_tag);

        echo "<script>
                alert('แก้ไขข้อมูลสินค้าและประเภทเรียบร้อยแล้ว'); 
                window.location='admin_goods_edit.php';
              </script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>