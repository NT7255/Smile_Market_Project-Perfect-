<?php
include "connect.php";

// ตั้งค่าเขตเวลาให้ตรงกับไทยเพื่อใช้ในชื่อไฟล์
date_default_timezone_set("Asia/Bangkok");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. รับค่าจากฟอร์มและป้องกัน SQL Injection
    $pro_name    = mysqli_real_escape_string($conn, $_POST['pro_name']);
    $pro_subinfo = mysqli_real_escape_string($conn, $_POST['pro_subinfo']);
    $pro_price   = $_POST['pro_price'];
    $pro_info    = mysqli_real_escape_string($conn, $_POST['pro_info']);
    $cat_id      = $_POST['cat_id'];

    // 2. Logic รันรหัสสินค้า PROxxx อัตโนมัติ (คงเดิมไว้)
    $res_id = mysqli_query($conn, "SELECT pro_id FROM tb_product ORDER BY pro_id DESC LIMIT 1");
    $row_id = mysqli_fetch_array($res_id);
    if($row_id) {
        $old_id = substr($row_id['pro_id'], 3); 
        $new_pro_id = "PRO" . str_pad((int)$old_id + 1, 3, "0", STR_PAD_LEFT);
    } else {
        $new_pro_id = "PRO001";
    }

    // 3. การจัดการรูปภาพแบบถาวร
    $pro_image = $_FILES['pro_image']['name'];
    $new_image_name = "default.jpg"; // ค่าเริ่มต้นถ้าไม่มีการอัปโหลด

    if($pro_image != "") {
        // สร้างชื่อไฟล์ใหม่โดยใช้: ชื่อเดิม + เวลาปัจจุบัน (กันชื่อซ้ำและสื่อความหมาย)
        $ext = pathinfo($pro_image, PATHINFO_EXTENSION);
        $original_name = pathinfo($pro_image, PATHINFO_FILENAME);
        // แทนที่อักขระพิเศษในชื่อไฟล์ด้วย _ เพื่อป้องกันปัญหาเว็บบราวเซอร์อ่านไม่ออก
        $safe_name = preg_replace('/[^a-zA-Z0-9_-]/', '_', $original_name);
        $new_image_name = $safe_name . "_" . time() . "." . $ext; 

        // ตรวจสอบและสร้างโฟลเดอร์เก็บภาพถ้ายังไม่มี
        $target_dir = "images/goods/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        // ย้ายไฟล์จากเครื่องผู้ใช้ไปเก็บใน Server
        move_uploaded_file($_FILES['pro_image']['tmp_name'], $target_dir . $new_image_name);
    }

    // 4. บันทึกลงฐานข้อมูล (เพิ่มข้อมูลลง 2 ตารางพร้อมกัน)
    // ตารางหลัก tb_product
    $sql_pro = "INSERT INTO tb_product (pro_id, pro_name, pro_price, pro_info, pro_image, pro_subinfo) 
                VALUES ('$new_pro_id', '$pro_name', '$pro_price', '$pro_info', '$new_image_name', '$pro_subinfo')";
    
    if(mysqli_query($conn, $sql_pro)) {
        // ตารางความสัมพันธ์ tb_tag (เพื่อระบุประเภทสินค้า)
        $sql_tag = "INSERT INTO tb_tag (pro_id, cat_id) VALUES ('$new_pro_id', '$cat_id')";
        mysqli_query($conn, $sql_tag);

        echo "<script>
                alert('บันทึกสินค้าใหม่ [$pro_name] และรูปภาพเรียบร้อยแล้ว');
                window.location.href='admin_goods_add.php';
              </script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>