<?php
session_start();
include_once "connect.php";
include_once "tab-menu.php"; 

// 1. รับค่ารหัสคำสั่งซื้อ
if(!isset($_GET['order_id'])){
    header("Location: notify_order.php");
    exit();
}
$order_id = mysqli_real_escape_string($conn, $_GET['order_id']);

// 2. ดึงข้อมูลหลักของคำสั่งซื้อ
$sql_order = "SELECT * FROM tb_order WHERE order_id = '$order_id'";
$res_order = mysqli_query($conn, $sql_order);
$order = mysqli_fetch_assoc($res_order);

if(!$order){
    echo "ไม่พบข้อมูลคำสั่งซื้อ";
    exit();
}

// กำหนดสถานะการจัดส่ง
$status_text = ($order['order_status'] == '1') ? "รอตรวจสอบการชำระเงิน" : "ชำระเงินแล้ว (กำลังเตรียมจัดส่ง)";
$status_color = ($order['order_status'] == '1') ? "#FFC107" : "#4CAF50";
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>รายละเอียดคำสั่งซื้อ #<?php echo $order_id; ?></title>
    <link rel="stylesheet" href="yellow_bg.css">
    <style>
        .detail-card { background: white; border-radius: 15px; padding: 25px; margin-top: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .status-banner { padding: 15px; border-radius: 10px; color: white; font-weight: bold; margin-bottom: 20px; text-align: center; }
        .product-item { display: flex; align-items: center; padding: 15px 0; border-bottom: 1px solid #eee; }
        .product-img { width: 80px; height: 80px; object-fit: cover; border-radius: 8px; margin-right: 20px; }
        .total-section { margin-top: 20px; text-align: right; font-size: 1.2em; font-weight: bold; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    </style>
</head>
<body class="yellow_bg">
    <?php include "tab-above-user2.php"; ?>
    
    <div class="main_size2 start-padding">
        <a href="notify_order.php" style="text-decoration: none; color: #666;">← ย้อนกลับ</a>
        
        <div class="detail-card">
            <div class="status-banner" style="background-color: <?php echo $status_color; ?>;">
                สถานะ: <?php echo $status_text; ?>
            </div>

            <div class="info-grid">
                <div>
                    <h4>📍 ที่อยู่จัดส่ง</h4>
                    <p><strong>ผู้รับ:</strong> <?php echo $order['member_name']; ?></p>
                    <p><strong>เบอร์โทร:</strong> <?php echo $order['member_tel']; ?></p>
                    <p><strong>ที่อยู่:</strong> <?php echo nl2br(htmlspecialchars($order['member_address'])); ?></p>
                </div>
                <div>
                    <h4>📄 ข้อมูลคำสั่งซื้อ</h4>
                    <p><strong>เลขที่:</strong> <?php echo $order['order_id']; ?></p>
                    <p><strong>วันที่สั่งซื้อ:</strong> <?php echo $order['order_date']; ?></p>
                </div>
            </div>

            <hr>

            <h4>📦 รายการสินค้า</h4>
            <?php
            $total_all = 0;
            // ดึงรายการสินค้าจาก tb_orderdetail JOIN กับ tb_product เพื่อเอาชื่อและรูปภาพ
            $sql_items = "SELECT od.*, p.pro_name, p.pro_image 
                         FROM tb_orderdetail od 
                         JOIN tb_product p ON od.pro_id = p.pro_id 
                         WHERE od.order_id = '$order_id'";
            $res_items = mysqli_query($conn, $sql_items);
            
            while($item = mysqli_fetch_assoc($res_items)){
                $subtotal = $item['price'] * $item['quantity'];
                $total_all += $subtotal;
            ?>
            <div class="product-item">
                <img src="images/goods/<?php echo $item['pro_image']; ?>" class="product-img">
                <div style="flex: 1;">
                    <div style="font-weight: bold;"><?php echo $item['pro_name']; ?></div>
                    <div style="color: #666;">฿<?php echo number_format($item['price'], 2); ?> x <?php echo $item['quantity']; ?></div>
                </div>
                <div style="font-weight: bold;">฿<?php echo number_format($subtotal, 2); ?></div>
            </div>
            <?php } ?>

            <div class="total-section">
                ยอดรวมสุทธิ: <span style="color: #FF8A00;">฿<?php echo number_format($total_all, 2); ?></span>
            </div>
        </div>
    </div>
</body>
</html>