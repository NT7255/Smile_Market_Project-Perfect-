<?php
include "connect.php";

// รับค่า id จาก URL
$pro_id = mysqli_real_escape_string($conn, $_GET['id']);

if ($pro_id != "") {
    
    // 1. ตรวจสอบว่าสินค้านี้เคยถูกสั่งซื้อไปหรือยัง (เช็คในตาราง tb_orderdetail)
    $sql_check_order = "SELECT pro_id FROM tb_orderdetail WHERE pro_id = '$pro_id' LIMIT 1";
    $res_check = mysqli_query($conn, $sql_check_order);

    if (mysqli_num_rows($res_check) > 0) {
        // --- กรณีมีการใช้งานอยู่ ให้แจ้งเตือนและหยุดการทำงาน ---
        echo "<script>
                alert('ไม่สามารถลบได้! เนื่องจากสินค้านี้มีการสั่งซื้ออยู่ในระบบ (มีประวัติใน Order)');
                window.location.href='admin_goods_edit.php';
              </script>";
        exit; // หยุดการทำงานทันที
    }

    // --- กรณีไม่มีการใช้งานใน Order ให้เริ่มกระบวนการลบ ---

    // 2. ดึงชื่อไฟล์รูปภาพเดิมมาเก็บไว้ก่อน
    $res_img = mysqli_query($conn, "SELECT pro_image FROM tb_product WHERE pro_id = '$pro_id'");
    $row_img = mysqli_fetch_array($res_img);
    $old_image_name = $row_img['pro_image'];

    // 3. ลบข้อมูลจากตาราง tb_tag (หมวดหมู่สินค้า)
    mysqli_query($conn, "DELETE FROM tb_tag WHERE pro_id = '$pro_id'");

    // 4. ลบข้อมูลจากตาราง tb_product
    $sql_delete = "DELETE FROM tb_product WHERE pro_id = '$pro_id'";
    
    if (mysqli_query($conn, $sql_delete)) {
        // 5. ลบไฟล์รูปภาพในโฟลเดอร์ (ถ้าไม่ใช่รูป default)
        if ($old_image_name != "" && $old_image_name != "default.jpg") {
            $file_path = "images/goods/" . $old_image_name;
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
        echo "<script>alert('ลบข้อมูลสินค้าเรียบร้อยแล้ว'); window.location='admin_goods_edit.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>