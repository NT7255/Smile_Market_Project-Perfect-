<?php
session_start();
include "connect.php";

if (!isset($_SESSION['m_id'])) {
    header("Location: login.php");
    exit();
}

$m_id = $_SESSION['m_id'];

// --- ส่วนบันทึกข้อมูล ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $name  = mysqli_real_escape_string($conn, $_POST['m_name']);
    $last  = mysqli_real_escape_string($conn, $_POST['m_last']);
    $email = mysqli_real_escape_string($conn, $_POST['m_email']);
    $tel   = mysqli_real_escape_string($conn, $_POST['m_tel']);
    $address = mysqli_real_escape_string($conn, $_POST['m_address']); // รับค่าที่อยู่

    $sql_update = "UPDATE tb_member SET 
                    member_name = '$name', 
                    member_lastname = '$last', 
                    member_email = '$email', 
                    member_tel = '$tel',
                    member_address = '$address' 
                    WHERE member_id = '$m_id'";

    if (mysqli_query($conn, $sql_update)) {
        echo "<script>alert('แก้ไขข้อมูลสำเร็จ'); window.location.href='edit.php';</script>";
        exit();
    }
}

// --- ส่วนดึงข้อมูลมาแสดง ---
$sql_fetch = "SELECT * FROM tb_member WHERE member_id = '$m_id'";
$result_fetch = mysqli_query($conn, $sql_fetch);
$user = mysqli_fetch_assoc($result_fetch);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>แก้ไขข้อมูลส่วนตัว</title>
    <link rel="stylesheet" href="edit.css">
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="tab-menu.css">
    <link rel="stylesheet" href="logout.css">
</head>
<body>
    <?php include "tab-above-user2.php"; ?>
    <div class="edit-profile-card">
        <h2>แก้ไขข้อมูลส่วนตัว</h2>
        <form action="edit.php" method="POST">
            <div class="input-group">
                <label>รหัสสมาชิก</label>
                <input type="text" class="input-field" value="<?php echo $user['member_id']; ?>" readonly>
            </div>
            <div class="row">
                <div class="input-group">
                    <label>ชื่อจริง</label>
                    <input type="text" name="m_name" class="input-field" value="<?php echo htmlspecialchars($user['member_name']); ?>" required>
                </div>
                <div class="input-group">
                    <label>นามสกุล</label>
                    <input type="text" name="m_last" class="input-field" value="<?php echo htmlspecialchars($user['member_lastname']); ?>" required>
                </div>
            </div>
            <div class="input-group">
                <label>อีเมล</label>
                <input type="email" name="m_email" class="input-field" value="<?php echo htmlspecialchars($user['member_email']); ?>" required>
            </div>
            <div class="input-group">
                <label>เบอร์โทรศัพท์</label>
                <input type="text" name="m_tel" class="input-field" value="<?php echo htmlspecialchars($user['member_tel']); ?>" required>
            </div>
            <div class="input-group">
                <label>ที่อยู่สำหรับการจัดส่ง</label>
                <textarea name="m_address" class="input-field" rows="4" required><?php echo htmlspecialchars($user['member_address']); ?></textarea>
            </div>
            <div class="form-actions">
                <a href="homepage.php" class="btn-cancel" style="text-decoration:none;">ยกเลิก</a>
                <button type="submit" name="update" class="btn-save">บันทึกข้อมูล</button>
            </div>
        </form>
    </div>
</body>
</html>