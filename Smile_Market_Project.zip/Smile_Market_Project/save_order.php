<?php
session_start();
include_once "connect.php"; // อ้างอิงจาก tab-menu.php

// 1. รับค่าจาก Form และ Session
$m_id = $_POST['member_id'];
$m_name = $_POST['member_name'];
$m_tel = $_POST['member_tel'];
$m_address = $_POST['member_address'];
$order_date = date("Y-m-d"); // บันทึกวันที่ปัจจุบัน
$order_status = "1"; // สถานะ 1: รอตรวจสอบ

// 2. การจัดการ File Upload (สลิปโอนเงิน)
$order_slip_image = "";
if (isset($_FILES['order_slip_image']) && $_FILES['order_slip_image']['name'] != "") {
    $ext = pathinfo($_FILES['order_slip_image']['name'], PATHINFO_EXTENSION);
    $new_name = "slip_" . time() . "_" . uniqid() . "." . $ext; // เปลี่ยนชื่อไฟล์เพื่อไม่ให้ซ้ำ
    $path = "uploads/" . $new_name;

    if (move_uploaded_file($_FILES['order_slip_image']['tmp_name'], $path)) {
        $order_slip_image = $new_name;
    }
}

// 3. สร้างรหัส Order ID (เช่น ORD + เลขสุ่ม)
$order_id = "ORD" . date("Ymd") . rand(100, 999);

// 4. บันทึกข้อมูลลง tb_order
$sql_order = "INSERT INTO tb_order (order_id, member_id, member_name, member_tel, member_address, order_date, order_slip_image, order_status) 
              VALUES ('$order_id', '$m_id', '$m_name', '$m_tel', '$m_address', '$order_date', '$order_slip_image', '$order_status')";

if (mysqli_query($conn, $sql_order)) {
    
    // 5. บันทึกรายละเอียดสินค้าลง tb_orderdetail โดยวนลูปจาก SESSION
    foreach ($_SESSION['cart'] as $pro_id => $quantity) {
        // ดึงราคาล่าสุดจาก tb_product
        $sql_pro = "SELECT pro_price FROM tb_product WHERE pro_id = '$pro_id'";
        $res_pro = mysqli_query($conn, $sql_pro);
        $row_pro = mysqli_fetch_assoc($res_pro);
        $price = $row_pro['pro_price'];

        $sql_detail = "INSERT INTO tb_orderdetail (order_id, member_id, pro_id, quantity, price) 
                       VALUES ('$order_id', '$m_id', '$pro_id', '$quantity', '$price')";
        mysqli_query($conn, $sql_detail);
    }

    // 6. เคลียร์ตะกร้าสินค้า
    unset($_SESSION['cart']);
    echo "<script>alert('สั่งซื้อสำเร็จ! รหัสใบสั่งซื้อของคุณคือ $order_id'); window.location='index.php';</script>";
} else {
    echo "เกิดข้อผิดพลาด: " . mysqli_error($conn);
}
?>