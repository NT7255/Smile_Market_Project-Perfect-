<?php
$conn = mysqli_connect("localhost", "root", "", "db_smilemarket");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
// ตั้งค่าภาษาให้รองรับภาษาไทย
mysqli_set_charset($conn, "utf8");
?>