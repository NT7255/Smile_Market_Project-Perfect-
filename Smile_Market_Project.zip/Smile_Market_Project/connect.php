<?php
$host = "localhost";
$username = "root";
$password = "";
$db_name = "db_smilemarket"; // ต้องตรงกับชื่อใน phpMyAdmin

$conn = mysqli_connect($host, $username, $password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// ตั้งค่าให้รองรับภาษาไทย
mysqli_set_charset($conn, "utf8");
?>